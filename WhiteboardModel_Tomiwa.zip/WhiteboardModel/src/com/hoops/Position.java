package com.hoops;

public enum Position {
    PG, SG, SF, PF, C, POSITION_LESS_PLAYER
}